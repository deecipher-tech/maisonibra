<?php

require_once __DIR__ . '/../includes/http.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tenant.php';
require_once __DIR__ . '/../includes/products.php';

send_cors_headers();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$path = request_path();
$parts = explode('/', $path);

try {
    if ($path === 'health') {
        ok(['status' => 'ok', 'service' => 'maison-ibra-api']);
    }

    if ($path === 'public/store' && $method === 'GET') {
        ok(['store' => public_store_payload(resolve_store())]);
    }

    if ($path === 'public/products' && $method === 'GET') {
        $store = resolve_store();
        $params = [(int) $store['id']];
        $where = 'p.store_id = ? AND p.status IN ("active", "out_of_stock")';

        if (!empty($_GET['category'])) {
            $where .= ' AND c.slug = ?';
            $params[] = trim((string) $_GET['category']);
        }

        if (!empty($_GET['slug'])) {
            $where .= ' AND p.slug = ?';
            $params[] = trim((string) $_GET['slug']);
        }

        $products = fetch_all(
            product_select_sql() . "
             WHERE {$where}
             ORDER BY p.featured DESC, p.sort_order ASC, p.created_at DESC",
            $params
        );

        ok(['products' => array_map(fn($row) => product_payload($row, false), $products)]);
    }

    if (($parts[0] ?? '') === 'public' && ($parts[1] ?? '') === 'products' && isset($parts[2]) && $method === 'GET') {
        $store = resolve_store();
        $row = fetch_one(
            product_select_sql() . ' WHERE p.store_id = ? AND p.slug = ? AND p.status IN ("active", "out_of_stock") LIMIT 1',
            [(int) $store['id'], (string) $parts[2]]
        );
        if (!$row) {
            fail('Product not found.', 404);
        }
        ok(['product' => product_payload($row, false)]);
    }

    if (($parts[0] ?? '') === 'media' && ($parts[1] ?? '') === 'products' && isset($parts[2]) && $method === 'GET') {
        $name = basename((string) $parts[2]);
        $pathToFile = product_storage_path('products/' . $name);
        if (!is_file($pathToFile)) {
            fail('Image not found.', 404);
        }
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($pathToFile) ?: 'application/octet-stream';
        if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
            fail('Image not found.', 404);
        }
        header('Content-Type: ' . $mime);
        header('Cache-Control: public, max-age=31536000, immutable');
        readfile($pathToFile);
        exit;
    }

    if ($path === 'auth/login' && $method === 'POST') {
        $body = read_json_body();
        ok(['account' => login_user((string) ($body['email'] ?? ''), (string) ($body['password'] ?? ''), (string) ($body['domain'] ?? ''))]);
    }

    if ($path === 'auth/register' && $method === 'POST') {
        ok(['account' => register_customer(read_json_body())], 201);
    }

    if ($path === 'auth/logout' && $method === 'POST') {
        logout_user();
        ok();
    }

    if ($path === 'auth/me' && $method === 'GET') {
        ok(['account' => current_account()]);
    }

    if ($path === 'admin/categories' && $method === 'GET') {
        $user = require_user();
        $rows = fetch_all(
            'SELECT id, slug, name, description, image_url, sort_order, status FROM categories WHERE store_id = ? ORDER BY sort_order ASC, name ASC',
            [(int) $user['store_id']]
        );
        ok(['categories' => $rows]);
    }

    if ($path === 'admin/products' && $method === 'GET') {
        $user = require_user();
        $params = [(int) $user['store_id']];
        $where = 'p.store_id = ? AND p.status <> "archived"';

        if (!empty($_GET['q'])) {
            $where .= ' AND p.name LIKE ?';
            $params[] = '%' . trim((string) $_GET['q']) . '%';
        }
        if (!empty($_GET['category'])) {
            $where .= ' AND c.slug = ?';
            $params[] = trim((string) $_GET['category']);
        }
        if (!empty($_GET['status'])) {
            $where .= ' AND p.status = ?';
            $params[] = trim((string) $_GET['status']);
        }

        $rows = fetch_all(
            product_select_sql() . " WHERE {$where} ORDER BY p.created_at DESC",
            $params
        );
        ok(['products' => array_map(fn($row) => product_payload($row, true), $rows)]);
    }

    if ($path === 'admin/products' && $method === 'POST') {
        $user = require_user();
        require_csrf_token();
        $savedFiles = [];
        $coverFile = uploaded_file_info('cover_image');
        $coverKey = $coverFile ? save_product_upload($coverFile, $savedFiles) : '';
        $body = parse_product_request();
        $product = validate_product_data($body, (int) $user['store_id'], null, $coverKey !== '');
        $additional = additional_uploads();

        db()->begin_transaction();
        try {
            execute_query(
                'INSERT INTO products
                 (store_id, category_id, slug, name, short_description, full_description, description, price, compare_at_price, sku, stock_quantity, status, featured, image_url, details_json)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    (int) $user['store_id'], $product['category_id'], $product['slug'], $product['name'],
                    $product['short_description'], $product['full_description'], $product['description'], $product['price'],
                    $product['compare_at_price'], $product['sku'], $product['stock_quantity'], $product['status'],
                    $product['featured'], $coverKey, $product['details_json'],
                ]
            );
            $productId = db()->insert_id;
            foreach ($additional as $i => $file) {
                $key = save_product_upload($file, $savedFiles);
                execute_query('INSERT INTO product_images (product_id, image_url, storage_key, alt_text, sort_order) VALUES (?, ?, ?, ?, ?)', [$productId, $key, $key, $product['name'], $i + 1]);
            }
            db()->commit();
            ok(['id' => $productId], 201);
        } catch (Throwable $e) {
            db()->rollback();
            foreach ($savedFiles as $file) if (is_file($file)) @unlink($file);
            throw $e;
        }
    }

    if (($parts[0] ?? '') === 'admin' && ($parts[1] ?? '') === 'products' && isset($parts[2])) {
        $user = require_user();
        $productId = (int) $parts[2];

        if ($method === 'GET') {
            $row = fetch_one(product_select_sql() . ' WHERE p.id = ? AND p.store_id = ? AND p.status <> "archived" LIMIT 1', [$productId, (int) $user['store_id']]);
            if (!$row) fail('Product not found.', 404);
            ok(['product' => product_payload($row, true)]);
        }

        if ($method === 'PUT' || $method === 'PATCH') {
            require_csrf_token();
            $existing = fetch_one('SELECT id, image_url FROM products WHERE id = ? AND store_id = ? AND status <> "archived"', [$productId, (int) $user['store_id']]);
            if (!$existing) fail('Product not found.', 404);

            $savedFiles = [];
            $coverFile = uploaded_file_info('cover_image');
            $newCoverKey = $coverFile ? save_product_upload($coverFile, $savedFiles) : (string) $existing['image_url'];
            $body = parse_product_request();
            $product = validate_product_data($body, (int) $user['store_id'], $productId, $newCoverKey !== '');
            $keepIds = array_filter(array_map('intval', explode(',', (string) ($body['keep_image_ids'] ?? ''))));
            $additional = additional_uploads();
            if (count($keepIds) + count($additional) > PRODUCT_ADDITIONAL_IMAGE_LIMIT) {
                fail('Image validation failed.', 422, ['additional_images' => 'Only three additional images are allowed.']);
            }

            db()->begin_transaction();
            try {
                execute_query(
                    'UPDATE products
                     SET category_id = ?, slug = ?, name = ?, short_description = ?, full_description = ?, description = ?,
                         price = ?, compare_at_price = ?, sku = ?, stock_quantity = ?, status = ?, featured = ?,
                         image_url = ?, details_json = ?
                     WHERE id = ? AND store_id = ?',
                    [
                        $product['category_id'], $product['slug'], $product['name'], $product['short_description'],
                        $product['full_description'], $product['description'], $product['price'], $product['compare_at_price'],
                        $product['sku'], $product['stock_quantity'], $product['status'], $product['featured'],
                        $newCoverKey, $product['details_json'], $productId, (int) $user['store_id'],
                    ]
                );

                $oldImages = fetch_all('SELECT id, image_url, storage_key FROM product_images WHERE product_id = ?', [$productId]);
                foreach ($oldImages as $img) {
                    if (!in_array((int) $img['id'], $keepIds, true)) {
                        execute_query('DELETE FROM product_images WHERE id = ? AND product_id = ?', [(int) $img['id'], $productId]);
                    }
                }
                $order = 1;
                foreach ($keepIds as $id) execute_query('UPDATE product_images SET sort_order = ? WHERE id = ? AND product_id = ?', [$order++, $id, $productId]);
                foreach ($additional as $file) {
                    $key = save_product_upload($file, $savedFiles);
                    execute_query('INSERT INTO product_images (product_id, image_url, storage_key, alt_text, sort_order) VALUES (?, ?, ?, ?, ?)', [$productId, $key, $key, $product['name'], $order++]);
                }
                db()->commit();
                if ($coverFile) delete_storage_if_unused((string) $existing['image_url']);
                foreach ($oldImages as $img) {
                    if (!in_array((int) $img['id'], $keepIds, true)) delete_storage_if_unused($img['storage_key'] ?: $img['image_url']);
                }
                ok(['id' => $productId]);
            } catch (Throwable $e) {
                db()->rollback();
                foreach ($savedFiles as $file) if (is_file($file)) @unlink($file);
                throw $e;
            }
        }

        if ($method === 'DELETE') {
            require_csrf_token();
            $row = fetch_one('SELECT id, image_url FROM products WHERE id = ? AND store_id = ?', [$productId, (int) $user['store_id']]);
            if (!$row) fail('Product not found.', 404);
            $referenced = fetch_one('SELECT id FROM order_items WHERE product_id = ? LIMIT 1', [$productId]);
            if ($referenced) {
                execute_query('UPDATE products SET status = "archived" WHERE id = ? AND store_id = ?', [$productId, (int) $user['store_id']]);
            } else {
                $images = fetch_all('SELECT image_url, storage_key FROM product_images WHERE product_id = ?', [$productId]);
                execute_query('DELETE FROM product_images WHERE product_id = ?', [$productId]);
                execute_query('DELETE FROM products WHERE id = ? AND store_id = ?', [$productId, (int) $user['store_id']]);
                delete_storage_if_unused((string) $row['image_url']);
                foreach ($images as $img) delete_storage_if_unused($img['storage_key'] ?: $img['image_url']);
            }
            ok();
        }
    }

    if ($path === 'admin/settings' && $method === 'GET') {
        $user = require_user();
        $store = fetch_one('SELECT settings_json, theme_json FROM stores WHERE id = ?', [(int) $user['store_id']]);
        ok([
            'settings' => json_decode($store['settings_json'] ?? '{}', true) ?: [],
            'theme' => json_decode($store['theme_json'] ?? '{}', true) ?: [],
        ]);
    }

    if ($path === 'admin/settings' && ($method === 'PUT' || $method === 'PATCH')) {
        $user = require_user();
        $body = read_json_body();
        $settings = json_encode($body['settings'] ?? new stdClass(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $theme = json_encode($body['theme'] ?? new stdClass(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        execute_query('UPDATE stores SET settings_json = ?, theme_json = ? WHERE id = ?', [$settings, $theme, (int) $user['store_id']]);
        ok();
    }

    fail('Route not found.', 404);
} catch (mysqli_sql_exception $e) {
    fail('Database query failed.', 500);
} catch (Throwable $e) {
    fail('Server error.', 500);
}

function public_product_payload(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'slug' => $row['slug'],
        'name' => $row['name'],
        'description' => $row['description'],
        'price' => (float) $row['price'],
        'compare_at_price' => $row['compare_at_price'] === null ? null : (float) $row['compare_at_price'],
        'sku' => $row['sku'],
        'stock_quantity' => (int) $row['stock_quantity'],
        'featured' => (bool) $row['featured'],
        'image_url' => $row['image_url'],
        'category' => [
            'slug' => $row['category_slug'],
            'name' => $row['category_name'],
        ],
        'details' => json_decode($row['details_json'] ?: '{}', true) ?: [],
    ];
}

function admin_product_payload(array $row): array
{
    return public_product_payload($row) + ['status' => $row['status']];
}

function validate_product_payload(array $body, int $storeId, ?int $productId = null): array
{
    $errors = [];
    $name = trim((string) ($body['name'] ?? ''));
    $slug = trim((string) ($body['slug'] ?? slugify($name)));
    $categorySlug = trim((string) ($body['category_slug'] ?? $body['type'] ?? ''));
    $price = isset($body['price']) ? (float) $body['price'] : -1;
    $status = (string) ($body['status'] ?? 'draft');

    if ($name === '') {
        $errors['name'] = 'Product name is required.';
    }
    if ($slug === '' || !preg_match('/^[a-z0-9-]+$/', $slug)) {
        $errors['slug'] = 'Slug must contain only lowercase letters, numbers, and hyphens.';
    }
    if ($price < 0) {
        $errors['price'] = 'Price must be zero or greater.';
    }
    if (!in_array($status, ['draft', 'active', 'archived'], true)) {
        $errors['status'] = 'Invalid product status.';
    }

    $category = $categorySlug === '' ? null : fetch_one(
        'SELECT id FROM categories WHERE store_id = ? AND slug = ? AND status = "active"',
        [$storeId, $categorySlug]
    );
    if (!$category) {
        $errors['category_slug'] = 'A valid category is required.';
    }

    $existing = $slug === '' ? null : fetch_one(
        'SELECT id FROM products WHERE store_id = ? AND slug = ? AND (? IS NULL OR id <> ?)',
        [$storeId, $slug, $productId, $productId]
    );
    if ($existing) {
        $errors['slug'] = 'Slug is already in use for this store.';
    }

    if ($errors) {
        fail('Product validation failed.', 422, $errors);
    }

    $details = $body['details'] ?? [];
    return [
        'category_id' => (int) $category['id'],
        'slug' => $slug,
        'name' => $name,
        'description' => trim((string) ($body['description'] ?? $body['desc'] ?? '')),
        'price' => $price,
        'compare_at_price' => isset($body['compare_at_price']) && $body['compare_at_price'] !== '' ? (float) $body['compare_at_price'] : null,
        'sku' => trim((string) ($body['sku'] ?? '')),
        'stock_quantity' => max(0, (int) ($body['stock_quantity'] ?? $body['stock'] ?? 0)),
        'status' => $status,
        'featured' => !empty($body['featured']) ? 1 : 0,
        'image_url' => trim((string) ($body['image_url'] ?? $body['image'] ?? '')),
        'details_json' => json_encode(is_array($details) ? $details : [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
    ];
}

function slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value);
    return trim((string) $value, '-');
}
