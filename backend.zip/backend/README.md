# MAISON IBRA API

Procedural PHP/MySQLi REST API for the multi-tenant storefront and merchant admin.

## Local Setup

1. Create `backend/config/config.local.php` from `backend/config/config.example.php`.
2. Update the database connection and allowed frontend origins.
3. Import `backend/database/schema.sql` into MySQL. It targets the local `e-commerce` database.
4. Visit `backend/public/health` to confirm the API is reachable.

The seed admin is:

- Email: `admin@maisonibra.local`
- Password: `password`

Change this immediately after setup. The frontend can point to another API host by setting `window.MAISON_API_BASE` before `assets/js/api.js` loads, or by setting `maison_api_base` in `localStorage` during development.

## Auth Behavior

`/auth/login` is shared. Merchant credentials return an `admin` account and can access protected `/admin/*` endpoints. Customer credentials return a `customer` account for public storefront pages only. `/auth/register` creates customer accounts for the resolved store domain.

## Tenant Resolution

Public endpoints resolve the store from the request host, `X-Store-Domain`, or a `domain` query parameter. Protected admin endpoints use the authenticated session's `store_id`, so merchants cannot operate on another store by changing request data.
