<?php
return [
    'app_env' => 'local',
    'app_url' => 'http://localhost/MAISON%20IBRA/backend',
    'frontend_origins' => [
        'http://localhost',
        'http://127.0.0.1',
        'https://your-vercel-domain.vercel.app',
    ],
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'e-commerce',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
    'session' => [
        'name' => 'maison_ibra_api',
        'secure' => false,
        'same_site' => 'Lax',
    ],
];
