<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/http.php';

function db(): mysqli
{
    static $db = null;

    if ($db instanceof mysqli) {
        return $db;
    }

    $cfg = config()['db'];
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    try {
        $db = new mysqli($cfg['host'], $cfg['user'], $cfg['pass'], $cfg['name'], (int) $cfg['port']);
        $db->set_charset($cfg['charset']);
    } catch (mysqli_sql_exception $e) {
        fail('Database connection failed.', 500);
    }

    return $db;
}

function fetch_one(string $sql, array $params = []): ?array
{
    $rows = fetch_all($sql, $params);
    return $rows[0] ?? null;
}

function fetch_all(string $sql, array $params = []): array
{
    $stmt = db()->prepare($sql);
    bind_params($stmt, $params);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

function execute_query(string $sql, array $params = []): mysqli_stmt
{
    $stmt = db()->prepare($sql);
    bind_params($stmt, $params);
    $stmt->execute();
    return $stmt;
}

function bind_params(mysqli_stmt $stmt, array $params): void
{
    if (!$params) {
        return;
    }

    $types = '';
    $values = [];
    foreach ($params as $param) {
        if (is_int($param)) {
            $types .= 'i';
        } elseif (is_float($param)) {
            $types .= 'd';
        } else {
            $types .= 's';
        }
        $values[] = $param;
    }

    $stmt->bind_param($types, ...$values);
}
