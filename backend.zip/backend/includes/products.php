<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';

const PRODUCT_IMAGE_MAX_BYTES = 2097152;
const PRODUCT_ADDITIONAL_IMAGE_LIMIT = 3;

function app_base_url(): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $base = rtrim(str_replace('/public/index.php', '', $script), '/');
    return $scheme . '://' . $host . $base . '/public';
}

function product_public_url(?string $path): string
{
    $path = trim((string) $path);
    if ($path === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $path) || str_starts_with($path, './') || str_starts_with($path, '/')) {
        return $path;
    }
    return app_base_url() . '/media/' . ltrim($path, '/');
}

function product_storage_path(string $storageKey): string
{
    return __DIR__ . '/../storage/' . ltrim($storageKey, '/');
}

function product_payload(array $row, bool $admin = false): array
{
    $details = json_decode($row['details_json'] ?: '{}', true) ?: [];
    $images = fetch_all(
        'SELECT id, image_url, storage_key, alt_text, sort_order FROM product_images WHERE product_id = ? ORDER BY sort_order ASC, id ASC',
        [(int) $row['id']]
    );

    $payload = [
        'id' => (int) $row['id'],
        'slug' => $row['slug'],
        'name' => $row['name'],
        'short_description' => $row['short_description'] ?? $row['description'],
        'description' => $row['short_description'] ?? $row['description'],
        'full_description' => $row['full_description'] ?? ($details['full_description'] ?? $row['description']),
        'price' => (float) $row['price'],
        'compare_at_price' => $row['compare_at_price'] === null ? null : (float) $row['compare_at_price'],
        'sku' => $row['sku'],
        'stock_quantity' => (int) $row['stock_quantity'],
        'featured' => (bool) $row['featured'],
        'image_url' => product_public_url($row['image_url']),
        'cover_storage_key' => $admin ? $row['image_url'] : null,
        'category' => [
            'slug' => $row['category_slug'],
            'name' => $row['category_name'],
        ],
        'images' => array_map(fn($img) => [
            'id' => (int) $img['id'],
            'url' => product_public_url($img['image_url']),
            'image_url' => product_public_url($img['image_url']),
            'storage_key' => $admin ? ($img['storage_key'] ?: $img['image_url']) : null,
            'alt_text' => $img['alt_text'],
            'sort_order' => (int) $img['sort_order'],
        ], $images),
        'specifications' => is_array($details['specifications'] ?? null) ? $details['specifications'] : [],
        'details' => $details,
        'created_at' => $row['created_at'] ?? null,
        'updated_at' => $row['updated_at'] ?? null,
    ];

    if ($admin) {
        $payload['status'] = $row['status'];
    }

    return $payload;
}

function product_select_sql(): string
{
    return 'SELECT p.id, p.slug, p.name, p.short_description, p.full_description, p.description,
                   p.price, p.compare_at_price, p.sku, p.stock_quantity, p.status, p.featured,
                   p.image_url, p.details_json, p.created_at, p.updated_at,
                   c.slug AS category_slug, c.name AS category_name
            FROM products p
            INNER JOIN categories c ON c.id = p.category_id';
}

function parse_product_request(): array
{
    if (str_starts_with($_SERVER['CONTENT_TYPE'] ?? '', 'multipart/form-data')) {
        return $_POST;
    }
    return read_json_body();
}

function uploaded_file_info(string $field): ?array
{
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    return $_FILES[$field];
}

function save_product_upload(array $file, array &$savedFiles): string
{
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        fail('Image upload failed.', 422, ['image' => 'Upload did not complete.']);
    }
    if (($file['size'] ?? 0) <= 0 || $file['size'] > PRODUCT_IMAGE_MAX_BYTES) {
        fail('Image validation failed.', 422, ['image' => 'Images must be 2MB or smaller.']);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) {
        fail('Image validation failed.', 422, ['image' => 'Only JPEG, PNG, and WebP images are allowed.']);
    }

    $dir = __DIR__ . '/../storage/products';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        fail('Could not prepare upload directory.', 500);
    }

    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    $target = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        fail('Could not store uploaded image.', 500);
    }

    $savedFiles[] = $target;
    return 'products/' . $name;
}

function delete_storage_if_unused(string $storageKey): void
{
    if ($storageKey === '' || preg_match('#^https?://#i', $storageKey) || str_starts_with($storageKey, './')) {
        return;
    }

    $usedCover = fetch_one('SELECT id FROM products WHERE image_url = ? AND status <> "archived" LIMIT 1', [$storageKey]);
    $usedImage = fetch_one('SELECT id FROM product_images WHERE image_url = ? OR storage_key = ? LIMIT 1', [$storageKey, $storageKey]);
    if ($usedCover || $usedImage) {
        return;
    }

    $path = product_storage_path($storageKey);
    if (is_file($path)) {
        @unlink($path);
    }
}

function validate_product_data(array $body, int $storeId, ?int $productId = null, bool $hasCover = false): array
{
    $errors = [];
    $name = trim((string) ($body['name'] ?? ''));
    $slug = trim((string) ($body['slug'] ?? slugify($name)));
    $categorySlug = trim((string) ($body['category_slug'] ?? $body['type'] ?? ''));
    $short = trim((string) ($body['short_description'] ?? $body['description'] ?? $body['desc'] ?? ''));
    $full = trim((string) ($body['full_description'] ?? ''));
    $price = isset($body['price']) ? (float) $body['price'] : -1;
    $compare = ($body['compare_at_price'] ?? '') === '' ? null : (float) $body['compare_at_price'];
    $stock = filter_var($body['stock_quantity'] ?? $body['stock'] ?? null, FILTER_VALIDATE_INT);
    $status = (string) ($body['status'] ?? 'draft');
    $featured = !empty($body['featured']) && $body['featured'] !== '0' ? 1 : 0;

    if ($name === '') $errors['name'] = 'Product name is required.';
    if ($slug === '' || !preg_match('/^[a-z0-9-]+$/', $slug)) $errors['slug'] = 'Slug must contain only lowercase letters, numbers, and hyphens.';
    if ($short === '') $errors['short_description'] = 'Short description is required.';
    if ($full === '') $errors['full_description'] = 'Full description is required.';
    if ($price < 0) $errors['price'] = 'Price must be zero or greater.';
    if ($compare !== null && ($compare < 0 || $compare >= $price)) $errors['compare_at_price'] = 'Discount price must be lower than the regular price.';
    if ($stock === false || $stock < 0) $errors['stock_quantity'] = 'Stock quantity must be a non-negative whole number.';
    if (!in_array($status, ['draft', 'active', 'out_of_stock'], true)) $errors['status'] = 'Invalid product status.';
    if (!$hasCover) $errors['cover_image'] = 'Product cover image is required.';

    $category = $categorySlug === '' ? null : fetch_one('SELECT id FROM categories WHERE store_id = ? AND slug = ? AND status = "active"', [$storeId, $categorySlug]);
    if (!$category) $errors['category_slug'] = 'A valid category is required.';

    $existing = $slug === '' ? null : fetch_one('SELECT id FROM products WHERE store_id = ? AND slug = ? AND (? IS NULL OR id <> ?)', [$storeId, $slug, $productId, $productId]);
    if ($existing) $errors['slug'] = 'Slug is already in use for this store.';

    if ($errors) fail('Product validation failed.', 422, $errors);

    $specs = [];
    $rawSpecs = $body['specifications'] ?? '[]';
    if (is_string($rawSpecs)) {
        $decoded = json_decode($rawSpecs, true);
        $rawSpecs = is_array($decoded) ? $decoded : [];
    }
    if (is_array($rawSpecs)) {
        foreach ($rawSpecs as $spec) {
            $key = trim((string) ($spec['key'] ?? ''));
            $value = trim((string) ($spec['value'] ?? ''));
            if ($key !== '' && $value !== '') $specs[] = ['key' => $key, 'value' => $value];
        }
    }

    return [
        'category_id' => (int) $category['id'],
        'slug' => $slug,
        'name' => $name,
        'short_description' => $short,
        'full_description' => $full,
        'description' => $short,
        'price' => $price,
        'compare_at_price' => $compare,
        'sku' => trim((string) ($body['sku'] ?? '')),
        'stock_quantity' => (int) $stock,
        'status' => $stock === 0 && $status === 'active' ? 'out_of_stock' : $status,
        'featured' => $featured,
        'details_json' => json_encode(['full_description' => $full, 'specifications' => $specs], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
    ];
}

function additional_uploads(): array
{
    if (empty($_FILES['additional_images'])) return [];
    $files = $_FILES['additional_images'];
    $count = is_array($files['name']) ? count($files['name']) : 0;
    $out = [];
    for ($i = 0; $i < $count; $i++) {
        if (($files['error'][$i] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
        $out[] = [
            'name' => $files['name'][$i],
            'type' => $files['type'][$i],
            'tmp_name' => $files['tmp_name'][$i],
            'error' => $files['error'][$i],
            'size' => $files['size'][$i],
        ];
    }
    if (count($out) > PRODUCT_ADDITIONAL_IMAGE_LIMIT) {
        fail('Image validation failed.', 422, ['additional_images' => 'Only three additional images are allowed.']);
    }
    return $out;
}
