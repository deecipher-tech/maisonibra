<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';
require_once __DIR__ . '/products.php';

/*
 * Store settings.
 *
 * Where each value lives:
 *   general.appName / currency / logo / favicon -> stores.name / currency / logo_url / favicon_url
 *   general.status, contact.*, social.*, banks  -> stores.settings_json
 * Other keys already inside settings_json (announce, delivery, ...) are preserved on every save.
 */

const SETTINGS_SECTIONS = ['general', 'contact', 'social', 'banks'];
const SETTINGS_BANK_LIMIT = 10;
const SETTINGS_CONTACT_KEYS = ['email', 'supportEmail', 'phone', 'whatsapp', 'address', 'hours'];
const SETTINGS_SOCIAL_KEYS = ['instagram', 'tiktok', 'facebook', 'x', 'whatsapp'];

function settings_decode(?string $json): array
{
    $data = json_decode($json ?: '{}', true);
    return is_array($data) ? $data : [];
}

/** Full settings object as the admin form edits it. */
function admin_settings_payload(array $store): array
{
    $json = settings_decode($store['settings_json'] ?? null);

    $contact = [];
    foreach (SETTINGS_CONTACT_KEYS as $key) {
        $contact[$key] = (string) ($json['contact'][$key] ?? '');
    }
    $social = [];
    foreach (SETTINGS_SOCIAL_KEYS as $key) {
        $social[$key] = (string) ($json['social'][$key] ?? '');
    }
    $banks = [];
    $storedBanks = is_array($json['banks'] ?? null) ? $json['banks'] : [];
    foreach ($storedBanks as $bank) {
        if (!is_array($bank)) {
            continue;
        }
        $banks[] = [
            'bank' => (string) ($bank['bank'] ?? ''),
            'name' => (string) ($bank['name'] ?? ''),
            'number' => (string) ($bank['number'] ?? ''),
        ];
    }

    return [
        'general' => [
            'appName' => (string) $store['name'],
            'currency' => (string) $store['currency'],
            'status' => (($json['general']['status'] ?? 'on') === 'off') ? 'off' : 'on',
            'logo' => product_public_url($store['logo_url'] ?? ''),
            'favicon' => product_public_url($store['favicon_url'] ?? ''),
        ],
        'contact' => $contact,
        'social' => $social,
        'banks' => $banks,
    ];
}

function load_admin_settings(int $storeId): array
{
    $store = fetch_one(
        'SELECT id, name, currency, logo_url, favicon_url, settings_json, theme_json FROM stores WHERE id = ?',
        [$storeId]
    );
    if (!$store) {
        fail('Store not found.', 404);
    }
    return [
        'settings' => admin_settings_payload($store),
        'theme' => settings_decode($store['theme_json'] ?? null),
    ];
}

/**
 * What the public storefront may see. Bank details and anything not listed here stay private.
 * `settings.announce` keeps its old position because script.js already reads it.
 */
function public_settings_view(array $settings): array
{
    $contact = [];
    foreach (SETTINGS_CONTACT_KEYS as $key) {
        $contact[$key] = (string) ($settings['contact'][$key] ?? '');
    }
    $social = [];
    foreach (SETTINGS_SOCIAL_KEYS as $key) {
        $social[$key] = (string) ($settings['social'][$key] ?? '');
    }

    return [
        'announce' => (string) ($settings['announce'] ?? ''),
        'delivery' => (object) (is_array($settings['delivery'] ?? null) ? $settings['delivery'] : []),
        'maintenance' => ($settings['general']['status'] ?? 'on') === 'off',
        'contact' => $contact,
        'social' => $social,
    ];
}

/**
 * Uploaded images arrive as the public URL (.../media/products/<file>); the database keeps only the storage key.
 */
function settings_media_ref(string $value): string
{
    $value = trim($value);
    if ($value !== '' && preg_match('#/media/(products/[A-Za-z0-9]+\.[A-Za-z0-9]+)(?:\?.*)?$#', $value, $m)) {
        return $m[1];
    }
    return $value;
}

function settings_media_ref_is_valid(string $value): bool
{
    if ($value === '') {
        return true;
    }
    if (strlen($value) > 500) {
        return false;
    }
    // Storage keys written by save_product_upload(): strict pattern so a key can never point outside storage/products.
    if (preg_match('#^products/[a-f0-9]{32}\.(jpg|png|webp)$#', $value)) {
        return true;
    }
    if (preg_match('#^\./[A-Za-z0-9_./ %-]+$#', $value) && strpos($value, '..') === false) {
        return true;
    }
    return (bool) preg_match('#^https?://#i', $value) && filter_var($value, FILTER_VALIDATE_URL) !== false;
}

function settings_text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

/**
 * Validates only the sections present in $input. Returns [cleanSections, errors].
 * Error keys are dotted field paths ("contact.email", "banks.0.number") so the UI can mark the right input.
 */
function validate_settings_input(array $input): array
{
    $errors = [];
    $clean = [];

    if (array_key_exists('general', $input)) {
        $g = is_array($input['general']) ? $input['general'] : [];
        $name = trim((string) ($g['appName'] ?? ''));
        $currency = trim((string) ($g['currency'] ?? ''));
        $status = (string) ($g['status'] ?? 'on');
        $logo = settings_media_ref((string) ($g['logo'] ?? ''));
        $favicon = settings_media_ref((string) ($g['favicon'] ?? ''));

        if ($name === '') {
            $errors['general.appName'] = 'App name is required.';
        } elseif (settings_text_length($name) > 160) {
            $errors['general.appName'] = 'App name must be 160 characters or fewer.';
        }
        if ($currency === '' || settings_text_length($currency) > 8) {
            $errors['general.currency'] = 'Currency symbol is required (8 characters at most).';
        }
        if (!in_array($status, ['on', 'off'], true)) {
            $errors['general.status'] = 'Invalid platform status.';
        }
        if (!settings_media_ref_is_valid($logo)) {
            $errors['general.logo'] = 'Logo must be an uploaded image, a relative path or an http(s) URL.';
        }
        if (!settings_media_ref_is_valid($favicon)) {
            $errors['general.favicon'] = 'Favicon must be an uploaded image, a relative path or an http(s) URL.';
        }
        $clean['general'] = ['appName' => $name, 'currency' => $currency, 'status' => $status, 'logo' => $logo, 'favicon' => $favicon];
    }

    if (array_key_exists('contact', $input)) {
        $c = is_array($input['contact']) ? $input['contact'] : [];
        $out = [];
        foreach (SETTINGS_CONTACT_KEYS as $key) {
            $out[$key] = trim((string) ($c[$key] ?? ''));
        }
        foreach (['email' => 'Email address', 'supportEmail' => 'Support email'] as $key => $label) {
            if ($out[$key] !== '' && (strlen($out[$key]) > 190 || !filter_var($out[$key], FILTER_VALIDATE_EMAIL))) {
                $errors["contact.$key"] = "$label must be a valid email address.";
            }
        }
        foreach (['phone' => 'Phone number', 'whatsapp' => 'WhatsApp number'] as $key => $label) {
            if ($out[$key] !== '' && !preg_match('/^[0-9+()\-\s]{6,30}$/', $out[$key])) {
                $errors["contact.$key"] = "$label may only contain digits, spaces, +, - and brackets (6-30 characters).";
            }
        }
        if (settings_text_length($out['address']) > 500) {
            $errors['contact.address'] = 'Address must be 500 characters or fewer.';
        }
        if (settings_text_length($out['hours']) > 160) {
            $errors['contact.hours'] = 'Opening hours must be 160 characters or fewer.';
        }
        $clean['contact'] = $out;
    }

    if (array_key_exists('social', $input)) {
        $s = is_array($input['social']) ? $input['social'] : [];
        $out = [];
        foreach (SETTINGS_SOCIAL_KEYS as $key) {
            $out[$key] = trim((string) ($s[$key] ?? ''));
            if ($out[$key] !== '' && (strlen($out[$key]) > 500 || !preg_match('#^https?://#i', $out[$key]) || filter_var($out[$key], FILTER_VALIDATE_URL) === false)) {
                $errors["social.$key"] = 'Enter a full link starting with http:// or https://.';
            }
        }
        $clean['social'] = $out;
    }

    if (array_key_exists('banks', $input)) {
        $list = $input['banks'];
        $out = [];
        if (!is_array($list) || (!empty($list) && array_keys($list) !== range(0, count($list) - 1))) {
            $errors['banks'] = 'Banks must be a list.';
        } elseif (count($list) > SETTINGS_BANK_LIMIT) {
            $errors['banks'] = 'You can save up to ' . SETTINGS_BANK_LIMIT . ' bank accounts.';
        } else {
            foreach ($list as $i => $bank) {
                $bank = is_array($bank) ? $bank : [];
                $row = [
                    'bank' => trim((string) ($bank['bank'] ?? '')),
                    'name' => trim((string) ($bank['name'] ?? '')),
                    'number' => trim((string) ($bank['number'] ?? '')),
                ];
                if ($row['bank'] === '' || settings_text_length($row['bank']) > 120) {
                    $errors["banks.$i.bank"] = 'Bank name is required (120 characters at most).';
                }
                if ($row['name'] === '' || settings_text_length($row['name']) > 160) {
                    $errors["banks.$i.name"] = 'Account name is required (160 characters at most).';
                }
                if (!preg_match('/^\d{6,20}$/', $row['number'])) {
                    $errors["banks.$i.number"] = 'Account number must be 6-20 digits.';
                }
                $out[] = $row;
            }
        }
        $clean['banks'] = $out;
    }

    return [$clean, $errors];
}

/** Deletes an uploaded logo/favicon file once nothing references it any more. */
function settings_release_media(string $key): void
{
    if (!preg_match('#^products/[a-f0-9]{32}\.(jpg|png|webp)$#', $key)) {
        return;
    }
    if (fetch_one('SELECT id FROM stores WHERE logo_url = ? OR favicon_url = ? LIMIT 1', [$key, $key])) {
        return;
    }
    delete_storage_if_unused($key); // also checks products and product_images
}

/** Applies validated sections. Sections that were not sent are left exactly as they were. */
function save_admin_settings(int $storeId, array $clean): array
{
    $store = fetch_one(
        'SELECT id, name, currency, logo_url, favicon_url, settings_json FROM stores WHERE id = ?',
        [$storeId]
    );
    if (!$store) {
        fail('Store not found.', 404);
    }

    $json = settings_decode($store['settings_json'] ?? null);
    foreach (['contact', 'social', 'banks'] as $section) {
        if (array_key_exists($section, $clean)) {
            $json[$section] = $clean[$section];
        }
    }

    $name = $store['name'];
    $currency = $store['currency'];
    $logo = $store['logo_url'];
    $favicon = $store['favicon_url'];
    if (isset($clean['general'])) {
        $g = $clean['general'];
        $name = $g['appName'];
        $currency = $g['currency'];
        $logo = $g['logo'] === '' ? null : $g['logo'];
        $favicon = $g['favicon'] === '' ? null : $g['favicon'];
        $json['general'] = ['status' => $g['status']];
    }

    execute_query(
        'UPDATE stores SET name = ?, currency = ?, logo_url = ?, favicon_url = ?, settings_json = ? WHERE id = ?',
        [$name, $currency, $logo, $favicon, json_encode($json, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $storeId]
    );

    foreach ([[$store['logo_url'], $logo], [$store['favicon_url'], $favicon]] as [$old, $new]) {
        if ($old && $old !== $new) {
            settings_release_media((string) $old);
        }
    }

    return load_admin_settings($storeId);
}

/** Logo / favicon upload. Reuses the product upload rules (JPEG/PNG/WebP, 2MB). Returns the key and its public URL. */
function save_settings_image(): array
{
    $file = uploaded_file_info('image');
    if (!$file) {
        fail('Choose an image to upload.', 422, ['image' => 'No file was received.']);
    }
    $savedFiles = [];
    $key = save_product_upload($file, $savedFiles);
    return ['key' => $key, 'url' => product_public_url($key)];
}