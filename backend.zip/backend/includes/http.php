<?php

require_once __DIR__ . '/config.php';

function send_cors_headers(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowed = config()['frontend_origins'];

    if ($origin && in_array($origin, $allowed, true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Credentials: true');
    }

    header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
}

function json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function ok(array $data = [], int $status = 200): void
{
    json_response(['ok' => true, 'data' => $data], $status);
}

function fail(string $message, int $status = 400, array $errors = []): void
{
    $payload = ['ok' => false, 'error' => ['message' => $message]];
    if ($errors) {
        $payload['error']['details'] = $errors;
    }
    json_response($payload, $status);
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        fail('Invalid JSON request body.', 400);
    }

    return $data;
}

function require_method(array $methods): void
{
    if (!in_array($_SERVER['REQUEST_METHOD'], $methods, true)) {
        fail('Method not allowed.', 405);
    }
}

function request_path(): string
{
    $uriPath = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $base = rtrim(str_replace('/public/index.php', '', $script), '/');

    if ($base !== '' && str_starts_with($uriPath, $base)) {
        $uriPath = substr($uriPath, strlen($base));
    }

    $uriPath = preg_replace('#^/public(?:/index\.php)?#', '', $uriPath);
    $path = trim($uriPath, '/');

    return $path === '' ? 'health' : $path;
}
