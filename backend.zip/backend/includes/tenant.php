<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';

function normalize_domain(string $domain): string
{
    $domain = strtolower(trim($domain));
    $domain = preg_replace('#^https?://#', '', $domain);
    $domain = preg_replace('#/.*$#', '', $domain);
    $domain = preg_replace('#:\d+$#', '', $domain);
    return $domain;
}

function requested_domain(): string
{
    $domain = $_GET['domain'] ?? ($_SERVER['HTTP_X_STORE_DOMAIN'] ?? ($_SERVER['HTTP_HOST'] ?? ''));
    return normalize_domain((string) $domain);
}

function resolve_store(?string $domain = null): array
{
    $domain = normalize_domain($domain ?: requested_domain());
    if ($domain === '') {
        fail('Store domain is required.', 422);
    }

    $store = fetch_one(
        'SELECT s.id, s.slug, s.name, s.currency, s.logo_url, s.favicon_url, s.theme_json,
                s.settings_json, s.status, d.domain
         FROM store_domains d
         INNER JOIN stores s ON s.id = d.store_id
         WHERE d.domain = ? AND d.status = "active" AND s.status = "active"
         LIMIT 1',
        [$domain]
    );

    if (!$store) {
        fail('Store not found for this domain.', 404);
    }

    return $store;
}

function public_store_payload(array $store): array
{
    return [
        'id' => (int) $store['id'],
        'slug' => $store['slug'],
        'domain' => $store['domain'],
        'name' => $store['name'],
        'currency' => $store['currency'],
        'logo_url' => $store['logo_url'],
        'favicon_url' => $store['favicon_url'],
        'theme' => json_decode($store['theme_json'] ?: '{}', true) ?: [],
        'settings' => json_decode($store['settings_json'] ?: '{}', true) ?: [],
    ];
}
