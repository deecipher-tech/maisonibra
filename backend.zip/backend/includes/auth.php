<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';

function start_api_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $cfg = config()['session'];
    session_name($cfg['name']);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => (bool) $cfg['secure'],
        'httponly' => true,
        'samesite' => $cfg['same_site'],
    ]);
    session_start();
}

function current_user(): ?array
{
    start_api_session();
    if (($_SESSION['account_type'] ?? '') !== 'admin') {
        return null;
    }

    $userId = $_SESSION['user_id'] ?? null;
    $storeId = $_SESSION['store_id'] ?? null;

    if (!$userId || !$storeId) {
        return null;
    }

    return fetch_one(
        'SELECT u.id, u.store_id, u.email, u.name, u.role, s.name AS store_name
         FROM users u
         INNER JOIN stores s ON s.id = u.store_id
         WHERE u.id = ? AND u.store_id = ? AND u.status = "active" AND s.status <> "deleted"',
        [(int) $userId, (int) $storeId]
    );
}

function require_user(): array
{
    $user = current_user();
    if (!$user) {
        fail('Authentication required.', 401);
    }

    return $user;
}

function csrf_token(): string
{
    start_api_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function require_csrf_token(): void
{
    start_api_session();
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        fail('Invalid security token.', 403);
    }
}

function current_customer(): ?array
{
    start_api_session();
    if (($_SESSION['account_type'] ?? '') !== 'customer') {
        return null;
    }

    $customerId = $_SESSION['customer_id'] ?? null;
    $storeId = $_SESSION['store_id'] ?? null;

    if (!$customerId || !$storeId) {
        return null;
    }

    return fetch_one(
        'SELECT c.id, c.store_id, c.email, c.name, c.phone, s.name AS store_name
         FROM customers c
         INNER JOIN stores s ON s.id = c.store_id
         WHERE c.id = ? AND c.store_id = ? AND c.status = "active" AND s.status = "active"',
        [(int) $customerId, (int) $storeId]
    );
}

function current_account(): ?array
{
    $user = current_user();
    if ($user) {
        return ['type' => 'admin', 'user' => $user, 'csrf_token' => csrf_token()];
    }

    $customer = current_customer();
    if ($customer) {
        return ['type' => 'customer', 'customer' => $customer, 'csrf_token' => csrf_token()];
    }

    return null;
}

function login_user(string $email, string $password, ?string $domain = null): array
{
    $email = strtolower(trim($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        fail('Invalid email or password.', 422);
    }

    $user = fetch_one(
        'SELECT u.id, u.store_id, u.email, u.name, u.role, u.password_hash, s.name AS store_name
         FROM users u
         INNER JOIN stores s ON s.id = u.store_id
         WHERE u.email = ? AND u.status = "active" AND s.status = "active"',
        [$email]
    );

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return login_customer($email, $password, $domain);
    }

    start_api_session();
    session_regenerate_id(true);
    $_SESSION['account_type'] = 'admin';
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['store_id'] = (int) $user['store_id'];
    unset($_SESSION['customer_id']);

    unset($user['password_hash']);
    return ['type' => 'admin', 'user' => $user, 'csrf_token' => csrf_token()];
}

function login_customer(string $email, string $password, ?string $domain = null): array
{
    require_once __DIR__ . '/tenant.php';

    $store = resolve_store($domain);
    $customer = fetch_one(
        'SELECT c.id, c.store_id, c.email, c.name, c.phone, c.password_hash, s.name AS store_name
         FROM customers c
         INNER JOIN stores s ON s.id = c.store_id
         WHERE c.store_id = ? AND c.email = ? AND c.status = "active" AND s.status = "active"',
        [(int) $store['id'], $email]
    );

    if (!$customer || !password_verify($password, $customer['password_hash'])) {
        fail('Invalid email or password.', 401);
    }

    start_api_session();
    session_regenerate_id(true);
    $_SESSION['account_type'] = 'customer';
    $_SESSION['customer_id'] = (int) $customer['id'];
    $_SESSION['store_id'] = (int) $customer['store_id'];
    unset($_SESSION['user_id']);

    unset($customer['password_hash']);
    return ['type' => 'customer', 'customer' => $customer, 'csrf_token' => csrf_token()];
}

function register_customer(array $body): array
{
    require_once __DIR__ . '/tenant.php';

    $store = resolve_store((string) ($body['domain'] ?? ''));
    $name = trim((string) ($body['name'] ?? ''));
    $email = strtolower(trim((string) ($body['email'] ?? '')));
    $phone = trim((string) ($body['phone'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $errors = [];

    if ($name === '') {
        $errors['name'] = 'Name is required.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'A valid email address is required.';
    }
    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    }
    if ($email && fetch_one('SELECT id FROM customers WHERE store_id = ? AND email = ?', [(int) $store['id'], $email])) {
        $errors['email'] = 'An account already exists for this email.';
    }

    if ($errors) {
        fail('Registration validation failed.', 422, $errors);
    }

    execute_query(
        'INSERT INTO customers (store_id, email, name, phone, password_hash, status) VALUES (?, ?, ?, ?, ?, "active")',
        [(int) $store['id'], $email, $name, $phone, password_hash($password, PASSWORD_DEFAULT)]
    );

    return login_customer($email, $password, (string) ($body['domain'] ?? ''));
}

function logout_user(): void
{
    start_api_session();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}
