<?php

function config(): array
{
    static $config = null;

    if ($config !== null) {
        return $config;
    }

    $localConfig = __DIR__ . '/../config/config.local.php';
    if (is_file($localConfig)) {
        $config = require $localConfig;
        return $config;
    }

    $origins = getenv('FRONTEND_ORIGINS') ?: 'http://localhost,http://127.0.0.1';
    $config = [
        'app_env' => getenv('APP_ENV') ?: 'local',
        'app_url' => getenv('APP_URL') ?: '',
        'frontend_origins' => array_values(array_filter(array_map('trim', explode(',', $origins)))),
        'db' => [
            'host' => getenv('DB_HOST') ?: '127.0.0.1',
            'port' => (int) (getenv('DB_PORT') ?: 3306),
            'name' => getenv('DB_DATABASE') ?: 'e-commerce',
            'user' => getenv('DB_USERNAME') ?: 'root',
            'pass' => getenv('DB_PASSWORD') ?: '',
            'charset' => getenv('DB_CHARSET') ?: 'utf8mb4',
        ],
        'session' => [
            'name' => getenv('SESSION_NAME') ?: 'maison_ibra_api',
            'secure' => filter_var(getenv('SESSION_SECURE') ?: false, FILTER_VALIDATE_BOOLEAN),
            'same_site' => getenv('SESSION_SAME_SITE') ?: 'Lax',
        ],
    ];

    return $config;
}
