<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';

/*
 * Categories & sub-categories (two levels: top-level category -> sub-category).
 *
 * The storefront hard-codes the three top-level categories below (category1/2/3.html, LABELS in products.js),
 * so they can be renamed, re-described and re-ordered but never deleted, re-slugged or turned into sub-categories.
 */

const PROTECTED_CATEGORY_SLUGS = ['perfume', 'skincare', 'makeup'];
const CATEGORY_STATUSES = ['active', 'hidden'];

function category_text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function category_select_sql(): string
{
    return 'SELECT c.id, c.parent_id, c.slug, c.name, c.description, c.image_url, c.sort_order, c.status,
                   c.created_at, c.updated_at,
                   pc.slug AS parent_slug, pc.name AS parent_name,
                   (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.status <> "archived") AS product_count,
                   (SELECT COUNT(*) FROM categories k WHERE k.parent_id = c.id) AS child_count
            FROM categories c
            LEFT JOIN categories pc ON pc.id = c.parent_id';
}

function category_payload(array $r): array
{
    $parentId = $r['parent_id'] === null ? null : (int) $r['parent_id'];
    return [
        'id' => (int) $r['id'],
        'parent_id' => $parentId,
        'slug' => $r['slug'],
        'name' => $r['name'],
        'description' => $r['description'],
        'image_url' => $r['image_url'],
        'sort_order' => (int) $r['sort_order'],
        'status' => $r['status'],
        'parent_slug' => $r['parent_slug'],
        'parent_name' => $r['parent_name'],
        'product_count' => (int) $r['product_count'],
        'child_count' => (int) $r['child_count'],
        'is_protected' => $parentId === null && in_array($r['slug'], PROTECTED_CATEGORY_SLUGS, true),
        'created_at' => $r['created_at'],
        'updated_at' => $r['updated_at'],
    ];
}

function category_list(int $storeId): array
{
    $rows = fetch_all(
        category_select_sql() . '
         WHERE c.store_id = ?
         ORDER BY COALESCE(pc.sort_order, c.sort_order) ASC, COALESCE(pc.id, c.id) ASC, (c.parent_id IS NOT NULL) ASC, c.sort_order ASC, c.name ASC',
        [$storeId]
    );
    return array_map('category_payload', $rows);
}

function category_find(int $storeId, int $id): ?array
{
    $row = fetch_one(category_select_sql() . ' WHERE c.id = ? AND c.store_id = ? LIMIT 1', [$id, $storeId]);
    return $row ? category_payload($row) : null;
}

/** Reads and validates a create/update body. Returns the cleaned values or responds with HTTP 422. */
function validate_category_input(array $body, int $storeId, ?array $existing = null): array
{
    $errors = [];
    $name = trim((string) ($body['name'] ?? ''));
    $slug = trim((string) ($body['slug'] ?? ''));
    if ($slug === '') {
        $slug = slugify($name);
    }
    $description = trim((string) ($body['description'] ?? ''));
    $status = (string) ($body['status'] ?? 'active');

    if ($name === '') {
        $errors['name'] = 'Category name is required.';
    } elseif (category_text_length($name) > 160) {
        $errors['name'] = 'Category name must be 160 characters or fewer.';
    }

    if ($slug === '' || !preg_match('/^[a-z0-9-]+$/', $slug) || strlen($slug) > 120) {
        $errors['slug'] = 'Slug is required and may only contain lowercase letters, numbers and hyphens (120 characters at most).';
    }
    if (category_text_length($description) > 500) {
        $errors['description'] = 'Description must be 500 characters or fewer.';
    }
    if (!in_array($status, CATEGORY_STATUSES, true)) {
        $errors['status'] = 'Status must be active or hidden.';
    }

    $sortRaw = $body['sort_order'] ?? '';
    $sort = null;
    if ($sortRaw !== '' && $sortRaw !== null) {
        $sort = filter_var($sortRaw, FILTER_VALIDATE_INT);
        if ($sort === false || $sort < 0 || $sort > 9999) {
            $errors['sort_order'] = 'Display order must be a whole number between 0 and 9999.';
            $sort = null;
        }
    }

    // Parent
    $parentRaw = $body['parent_id'] ?? null;
    $parentId = null;
    if ($parentRaw !== null && $parentRaw !== '' && $parentRaw !== 0 && $parentRaw !== '0') {
        $parentId = filter_var($parentRaw, FILTER_VALIDATE_INT);
        if ($parentId === false || $parentId < 1) {
            $errors['parent_id'] = 'Choose a valid parent category.';
            $parentId = null;
        } elseif ($existing && $parentId === $existing['id']) {
            $errors['parent_id'] = 'A category cannot be its own parent.';
        } else {
            $parent = category_find($storeId, $parentId);
            if (!$parent) {
                $errors['parent_id'] = 'The selected parent category does not exist.';
            } elseif ($parent['parent_id'] !== null) {
                $errors['parent_id'] = 'Sub-categories can only be placed under a top-level category.';
            } elseif ($existing && $existing['child_count'] > 0) {
                $errors['parent_id'] = 'This category has sub-categories, so it cannot become a sub-category itself.';
            }
        }
    }

    if ($existing && $existing['is_protected']) {
        if ($slug !== $existing['slug']) {
            $errors['slug'] = 'The slug of a core category is used by the storefront and cannot be changed.';
        }
        if ($parentId !== null) {
            $errors['parent_id'] = 'A core category must stay top-level.';
        }
    }

    // Slug is unique per store.
    if (!isset($errors['slug'])) {
        $dupe = $existing
            ? fetch_one('SELECT id FROM categories WHERE store_id = ? AND slug = ? AND id <> ? LIMIT 1', [$storeId, $slug, $existing['id']])
            : fetch_one('SELECT id FROM categories WHERE store_id = ? AND slug = ? LIMIT 1', [$storeId, $slug]);
        if ($dupe) {
            $errors['slug'] = 'This slug is already used by another category.';
        }
    }

    if ($errors) {
        fail('Category validation failed.', 422, $errors);
    }

    return [
        'parent_id' => $parentId,
        'slug' => $slug,
        'name' => $name,
        'description' => $description === '' ? null : $description,
        'sort_order' => $sort,
        'status' => $status,
    ];
}

function next_category_sort(int $storeId, ?int $parentId): int
{
    $row = $parentId === null
        ? fetch_one('SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM categories WHERE store_id = ? AND parent_id IS NULL', [$storeId])
        : fetch_one('SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM categories WHERE store_id = ? AND parent_id = ?', [$storeId, $parentId]);
    return (int) ($row['n'] ?? 1);
}

function create_category(int $storeId, array $data): array
{
    $sort = $data['sort_order'] ?? next_category_sort($storeId, $data['parent_id']);
    execute_query(
        'INSERT INTO categories (store_id, parent_id, slug, name, description, sort_order, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [$storeId, $data['parent_id'], $data['slug'], $data['name'], $data['description'], $sort, $data['status']]
    );
    return category_find($storeId, (int) db()->insert_id);
}

function update_category(int $storeId, array $existing, array $data): array
{
    $sort = $data['sort_order'];
    if ($sort === null) {
        // Keep the current position unless the category moved to another parent.
        $sort = $data['parent_id'] === $existing['parent_id']
            ? $existing['sort_order']
            : next_category_sort($storeId, $data['parent_id']);
    }
    execute_query(
        'UPDATE categories SET parent_id = ?, slug = ?, name = ?, description = ?, sort_order = ?, status = ? WHERE id = ? AND store_id = ?',
        [$data['parent_id'], $data['slug'], $data['name'], $data['description'], $sort, $data['status'], $existing['id'], $storeId]
    );
    return category_find($storeId, $existing['id']);
}

/**
 * Safe delete:
 *  - core categories and categories that still have sub-categories are refused (409);
 *  - a category that still has products is refused (409, with the product count) unless $reassignTo names
 *    another active category, in which case the products are moved there and the delete happens in one transaction.
 * Archived products count too: they still reference the category through a foreign key.
 */
function delete_category(int $storeId, int $id, ?int $reassignTo): int
{
    $category = category_find($storeId, $id);
    if (!$category) {
        fail('Category not found.', 404);
    }
    if ($category['is_protected']) {
        fail('This is a core category used by the storefront pages and cannot be deleted. You can hide it instead.', 409);
    }
    if ($category['child_count'] > 0) {
        fail('This category still has sub-categories. Delete or move them first.', 409, ['child_count' => $category['child_count']]);
    }

    $count = fetch_one('SELECT COUNT(*) AS n FROM products WHERE category_id = ? AND store_id = ?', [$id, $storeId]);
    $products = (int) ($count['n'] ?? 0);

    if ($products > 0) {
        if ($reassignTo === null) {
            fail('This category still has ' . $products . ' product' . ($products === 1 ? '' : 's') . '. Choose a category to move them to.', 409, ['product_count' => $products]);
        }
        if ($reassignTo === $id) {
            fail('Choose a different category to move the products to.', 422, ['reassign_to' => 'Choose a different category.']);
        }
        $target = category_find($storeId, $reassignTo);
        if (!$target) {
            fail('The category to move products to does not exist.', 422, ['reassign_to' => 'Choose a valid category.']);
        }
        if ($target['status'] !== 'active') {
            fail('Products can only be moved to an active category.', 422, ['reassign_to' => 'Choose an active category.']);
        }
    }

    db()->begin_transaction();
    try {
        if ($products > 0) {
            execute_query('UPDATE products SET category_id = ? WHERE category_id = ? AND store_id = ?', [$reassignTo, $id, $storeId]);
        }
        execute_query('DELETE FROM categories WHERE id = ? AND store_id = ?', [$id, $storeId]);
        db()->commit();
    } catch (Throwable $e) {
        db()->rollback();
        throw $e;
    }

    return $products;
}