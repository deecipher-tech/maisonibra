-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2026 at 08:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerce`
--
CREATE DATABASE IF NOT EXISTS `e-commerce` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `e-commerce`;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED DEFAULT NULL,
  `cart_token` char(64) NOT NULL,
  `status` enum('open','converted','abandoned') NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `cart_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `slug` varchar(120) NOT NULL,
  `name` varchar(160) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','hidden') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `store_id`, `parent_id`, `slug`, `name`, `description`, `image_url`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'perfume', 'Perfume', 'Discover your signature scent.', './assets/images/perfume-ca.png', 1, 'active', '2026-10-09 12:17:23', '2026-10-09 12:17:23'),
(2, 1, NULL, 'skincare', 'Skincare', 'Rituals for radiant skin.', './assets/images/skincare -ca.png', 2, 'active', '2026-10-09 12:17:23', '2026-10-09 12:17:23'),
(3, 1, NULL, 'makeup', 'Makeup', 'Beauty with intention.', './assets/images/makeup-ca.png', 3, 'active', '2026-10-09 12:17:23', '2026-10-09 12:17:23'),
(4, 1, 1, 'attar-oil', 'Attar Oil', 'Concentrated perfume oils (attar).', NULL, 1, 'active', '2026-10-10 22:57:12', '2026-10-10 22:57:12'),
(5, 1, 1, 'eau-de-parfum', 'Eau de Parfum', 'Eau de parfum in 100ml bottles.', NULL, 2, 'active', '2026-10-10 22:57:12', '2026-10-10 22:57:12'),
(6, 1, 1, 'roll-on-perfume-oil', 'Roll-On Perfume Oil', 'Roll-on perfume oils in 24ml.', NULL, 3, 'active', '2026-10-10 22:57:12', '2026-10-10 22:57:12'),
(7, 1, 1, 'body-spray', 'Deodorant / Body Spray', 'Lattafa deodorant and body sprays.', NULL, 4, 'active', '2026-10-10 22:57:12', '2026-10-10 22:57:12'),
(18, 1, 2, 'facial-cleansers', 'Facial Cleansers', 'Gentle, foaming and treatment cleansers for every skin type.', NULL, 1, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(19, 1, 2, 'face-serums', 'Face Serums', 'Targeted serums with vitamin C, niacinamide, retinol and more.', NULL, 2, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(20, 1, 2, 'face-moisturizers', 'Face Moisturizers', 'Hydrating creams, gels and barrier repair moisturizers.', NULL, 3, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(21, 1, 2, 'sunscreens', 'Sunscreens', 'SPF 30 and SPF 50 protection for every skin type.', NULL, 4, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(22, 1, 2, 'body-care', 'Body Care', 'Lotions, creams, butters and oils for soft, nourished skin.', NULL, 5, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(23, 1, 2, 'bath-body-cleansers', 'Bath & Body Cleansers', 'Shower gels, body washes, soaps and exfoliating scrubs.', NULL, 6, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(24, 1, 2, 'lip-care', 'Lip Care', 'Balms, masks, scrubs and treatments for soft, healthy lips.', NULL, 7, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(25, 1, 2, 'toners-makeup-removers', 'Toners & Makeup Removers', 'Toners, micellar water, cleansing balms and oils.', NULL, 8, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(26, 1, 2, 'personal-care', 'Personal Care', 'Deodorants, antiperspirants and underarm care essentials.', NULL, 9, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(27, 1, 2, 'face-masks-treatments', 'Face Masks & Treatments', 'Clay masks, sheet masks, patches and spot treatments.', NULL, 10, 'active', '2026-10-11 02:26:49', '2026-10-11 02:26:49'),
(48, 1, 3, 'face-makeup', 'Face Makeup', 'Foundations, concealers, powders and complexion essentials.', NULL, 1, 'active', '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(49, 1, 3, 'lip-makeup', 'Lip Makeup', 'Lipsticks, glosses, liners and tints for every look.', NULL, 2, 'active', '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(50, 1, 3, 'eye-makeup', 'Eye Makeup', 'Eyebrow, eyeliner, mascara and eyeshadow essentials.', NULL, 3, 'active', '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(51, 1, 3, 'makeup-primers-setting', 'Makeup Primers & Setting Products', 'Primers, setting sprays and fixing sprays for long wear.', NULL, 4, 'active', '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(52, 1, 3, 'makeup-tools-accessories', 'Makeup Tools & Accessories', 'Brushes, sponges, curlers and beauty accessories.', NULL, 5, 'active', '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(53, 1, 3, 'makeup-removal', 'Makeup Removal', 'Micellar water, wipes, balms and cleansing pads.', NULL, 6, 'active', '2026-10-11 02:40:09', '2026-10-11 02:40:09');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `name` varchar(160) NOT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `store_id`, `email`, `name`, `phone`, `password_hash`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'customer1791548412133@example.com', 'Test Customer', '08000000000', '$2y$10$xR1IJthENOdOcDv6SJeYIuJsdsbNensaIrBlrwOdbqsIm6HRrea.S', 'active', '2026-10-09 12:20:12', '2026-10-09 12:20:12'),
(2, 1, 'customer1791548475757@example.com', 'Test Customer', '08000000000', '$2y$10$0vDiCdmso5iRfJD8xZTiv.RZMi7REvN6N9jgB1awXNyPyMrrZjQIW', 'active', '2026-10-09 12:21:15', '2026-10-09 12:21:15'),
(3, 1, 'customer1791548519573@example.com', 'Test Customer', '08000000000', '$2y$10$BASKSb2J2o3DXgMGRb0JN.h3wSw6k9PjKj4zxL4NWfaEHNt00dpzC', 'active', '2026-10-09 12:21:59', '2026-10-09 12:21:59');

-- --------------------------------------------------------

--
-- Table structure for table `merchants`
--

CREATE TABLE `merchants` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `email` varchar(190) NOT NULL,
  `status` enum('active','suspended','deleted') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `merchants`
--

INSERT INTO `merchants` (`id`, `name`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'MAISON IBRA', 'owner@maisonibra.local', 'active', '2026-10-09 12:17:23', '2026-10-09 12:17:23');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED DEFAULT NULL,
  `order_number` varchar(40) NOT NULL,
  `customer_name` varchar(160) NOT NULL,
  `customer_email` varchar(190) NOT NULL,
  `customer_phone` varchar(60) DEFAULT NULL,
  `delivery_address` text DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `delivery_fee` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  `fulfillment_status` enum('new','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'new',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `product_name` varchar(190) NOT NULL,
  `sku` varchar(120) DEFAULT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(140) NOT NULL,
  `name` varchar(190) NOT NULL,
  `short_description` text DEFAULT NULL,
  `full_description` mediumtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `compare_at_price` decimal(12,2) DEFAULT NULL,
  `sku` varchar(120) DEFAULT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `status` enum('draft','active','out_of_stock','archived') NOT NULL DEFAULT 'draft',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `image_url` varchar(500) NOT NULL DEFAULT '',
  `details_json` longtext DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `store_id`, `category_id`, `slug`, `name`, `short_description`, `full_description`, `description`, `price`, `compare_at_price`, `sku`, `stock_quantity`, `status`, `featured`, `image_url`, `details_json`, `sort_order`, `created_at`, `updated_at`) VALUES
(195, 1, 52, 'eyeshadow-brushes', 'Eyeshadow Brushes', 'Eyeshadow brushes for blending, packing and detailing.', 'These Eyeshadow Brushes cover everything from packing colour to blending and detailing. The soft bristles pick up pigment evenly and blend with ease.\n\nUse the flat brush to apply shadow, the fluffy brush to blend, and the small brush to define the crease or lower lash line. Wash regularly.', 'Eyeshadow brushes for blending, packing and detailing.', 9500.00, NULL, NULL, 80, 'active', 0, '', '{\"full_description\":\"These Eyeshadow Brushes cover everything from packing colour to blending and detailing. The soft bristles pick up pigment evenly and blend with ease.\\n\\nUse the flat brush to apply shadow, the fluffy brush to blend, and the small brush to define the crease or lower lash line. Wash regularly.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Eyeshadow Brushes\"},{\"key\":\"Bristles\",\"value\":\"Synthetic\"},{\"key\":\"Pieces\",\"value\":\"5\"},{\"key\":\"Includes\",\"value\":\"Flat, fluffy, angled, pencil, smudge\"},{\"key\":\"Care\",\"value\":\"Wash regularly\"},{\"key\":\"Handle\",\"value\":\"Wooden\"}]}', 6, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(196, 1, 52, 'powder-puff', 'Powder Puff', 'A soft powder puff for pressing powder into skin.', 'This Powder Puff is a soft, velvety puff ideal for pressing setting powder or loose powder into the skin for a smooth, long-lasting finish.\n\nDip the puff into powder, tap off the excess, then press gently over the face. Use a clean puff regularly and wash with gentle soap.', 'A soft powder puff for pressing powder into skin.', 2500.00, NULL, NULL, 200, 'active', 0, '', '{\"full_description\":\"This Powder Puff is a soft, velvety puff ideal for pressing setting powder or loose powder into the skin for a smooth, long-lasting finish.\\n\\nDip the puff into powder, tap off the excess, then press gently over the face. Use a clean puff regularly and wash with gentle soap.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Powder Puff\"},{\"key\":\"Material\",\"value\":\"Soft velour\"},{\"key\":\"Pack Size\",\"value\":\"2 pieces\"},{\"key\":\"Application\",\"value\":\"Press powder onto skin\"},{\"key\":\"Care\",\"value\":\"Wash regularly\"},{\"key\":\"Works With\",\"value\":\"Loose and pressed powder\"}]}', 7, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(197, 1, 52, 'eyelash-curler', 'Eyelash Curler', 'An eyelash curler for lifted, curled lashes.', 'This Eyelash Curler gently lifts and curls lashes for a wide-awake look. Use it before mascara to make lashes look longer and more open.\n\nPlace the curler at the base of the lashes, press gently, hold for a few seconds, then move up the lash in small steps. Replace the silicone pad when worn.', 'An eyelash curler for lifted, curled lashes.', 4500.00, NULL, NULL, 120, 'active', 0, '', '{\"full_description\":\"This Eyelash Curler gently lifts and curls lashes for a wide-awake look. Use it before mascara to make lashes look longer and more open.\\n\\nPlace the curler at the base of the lashes, press gently, hold for a few seconds, then move up the lash in small steps. Replace the silicone pad when worn.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Eyelash Curler\"},{\"key\":\"Material\",\"value\":\"Stainless steel\"},{\"key\":\"Handle\",\"value\":\"Ergonomic\"},{\"key\":\"Use\",\"value\":\"Before mascara\"},{\"key\":\"Refill Pads\",\"value\":\"2 included\"},{\"key\":\"Care\",\"value\":\"Wipe clean\"}]}', 8, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(198, 1, 52, 'tweezers', 'Tweezers', 'Precision tweezers for shaping brows and lashes.', 'These Tweezers have a precise slanted tip for shaping brows and removing stray hairs with accuracy. The stainless steel body is durable and easy to clean.\n\nGrip the hair as close to the root as possible and pull in the direction of hair growth. Wipe the tips with alcohol after use.', 'Precision tweezers for shaping brows and lashes.', 3500.00, NULL, NULL, 150, 'active', 0, '', '{\"full_description\":\"These Tweezers have a precise slanted tip for shaping brows and removing stray hairs with accuracy. The stainless steel body is durable and easy to clean.\\n\\nGrip the hair as close to the root as possible and pull in the direction of hair growth. Wipe the tips with alcohol after use.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Tweezers\"},{\"key\":\"Material\",\"value\":\"Stainless steel\"},{\"key\":\"Tip\",\"value\":\"Slanted\"},{\"key\":\"Use\",\"value\":\"Brows and stray hairs\"},{\"key\":\"Care\",\"value\":\"Wipe with alcohol\"},{\"key\":\"Durable\",\"value\":\"Yes\"}]}', 9, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(199, 1, 52, 'makeup-bag', 'Makeup Bag', 'A makeup bag for organising beauty essentials.', 'This Makeup Bag keeps your beauty essentials organised and easy to find. Its durable material and practical size make it perfect for travel and daily use.\n\nStore your brushes, makeup and skincare inside, and wipe the interior clean as needed. Zip closed when not in use.', 'A makeup bag for organising beauty essentials.', 8500.00, NULL, NULL, 100, 'active', 1, '', '{\"full_description\":\"This Makeup Bag keeps your beauty essentials organised and easy to find. Its durable material and practical size make it perfect for travel and daily use.\\n\\nStore your brushes, makeup and skincare inside, and wipe the interior clean as needed. Zip closed when not in use.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Makeup Bag\"},{\"key\":\"Material\",\"value\":\"Durable fabric\"},{\"key\":\"Closure\",\"value\":\"Zip\"},{\"key\":\"Size\",\"value\":\"Medium\"},{\"key\":\"Use\",\"value\":\"Travel and daily\"},{\"key\":\"Care\",\"value\":\"Wipe clean\"}]}', 10, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(200, 1, 52, 'handheld-makeup-mirror', 'Handheld Makeup Mirror', 'A handheld mirror for precise makeup application.', 'This Handheld Makeup Mirror is compact and easy to hold, making it ideal for precise makeup application and touch-ups on the go. It fits neatly into most makeup bags.\n\nHold the mirror at a comfortable distance and check your makeup from different angles. Wipe clean with a soft cloth after use.', 'A handheld mirror for precise makeup application.', 4500.00, NULL, NULL, 120, 'active', 0, '', '{\"full_description\":\"This Handheld Makeup Mirror is compact and easy to hold, making it ideal for precise makeup application and touch-ups on the go. It fits neatly into most makeup bags.\\n\\nHold the mirror at a comfortable distance and check your makeup from different angles. Wipe clean with a soft cloth after use.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Handheld Mirror\"},{\"key\":\"Size\",\"value\":\"Medium\"},{\"key\":\"Frame\",\"value\":\"Durable plastic\"},{\"key\":\"Use\",\"value\":\"Makeup and touch-ups\"},{\"key\":\"Portable\",\"value\":\"Yes\"},{\"key\":\"Care\",\"value\":\"Wipe clean\"}]}', 11, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(201, 1, 52, 'pencil-sharpener', 'Pencil Sharpener', 'A pencil sharpener for liners and brow pencils.', 'This Pencil Sharpener keeps your lip liners, eyeliners and brow pencils sharp and precise. Its compact size makes it easy to carry in your makeup bag.\n\nInsert the pencil and twist gently to sharpen. Empty the shavings regularly and wipe the blade clean as needed.', 'A pencil sharpener for liners and brow pencils.', 2500.00, NULL, NULL, 180, 'active', 0, '', '{\"full_description\":\"This Pencil Sharpener keeps your lip liners, eyeliners and brow pencils sharp and precise. Its compact size makes it easy to carry in your makeup bag.\\n\\nInsert the pencil and twist gently to sharpen. Empty the shavings regularly and wipe the blade clean as needed.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Pencil Sharpener\"},{\"key\":\"Blade\",\"value\":\"Stainless steel\"},{\"key\":\"Sizes\",\"value\":\"Standard and jumbo\"},{\"key\":\"Use\",\"value\":\"Lip, eye and brow pencils\"},{\"key\":\"Portable\",\"value\":\"Yes\"},{\"key\":\"Care\",\"value\":\"Empty regularly\"}]}', 12, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(202, 1, 53, 'micellar-water-makeup-removal', 'Micellar Water', 'A no-rinse micellar water for gentle makeup removal.', 'This Micellar Water gently lifts makeup, sunscreen and daily grime with a no-rinse formula. It is suitable for all skin types, including sensitive skin.\n\nSaturate a cotton pad and gently wipe over the face, eyes and lips. No rinsing needed. Follow with your usual skincare routine.', 'A no-rinse micellar water for gentle makeup removal.', 7500.00, NULL, NULL, 90, 'active', 1, '', '{\"full_description\":\"This Micellar Water gently lifts makeup, sunscreen and daily grime with a no-rinse formula. It is suitable for all skin types, including sensitive skin.\\n\\nSaturate a cotton pad and gently wipe over the face, eyes and lips. No rinsing needed. Follow with your usual skincare routine.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Micellar Water\"},{\"key\":\"Skin Type\",\"value\":\"All Skin Types\"},{\"key\":\"Key Benefit\",\"value\":\"Removes makeup, no rinse\"},{\"key\":\"Volume\",\"value\":\"400ml\"},{\"key\":\"Application\",\"value\":\"Cotton pad, wipe gently\"},{\"key\":\"Fragrance-Free\",\"value\":\"Yes\"}]}', 1, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(203, 1, 53, 'makeup-remover-wipes', 'Makeup Remover Wipes', 'Makeup remover wipes for quick, on-the-go cleansing.', 'These Makeup Remover Wipes quickly remove makeup, oil and impurities in one step. They are ideal for travel, the gym or late nights.\n\nTake a wipe and gently sweep over the face, eyes and lips until clean. Reseal the pack to keep the wipes fresh. Follow with cleanser if desired.', 'Makeup remover wipes for quick, on-the-go cleansing.', 5500.00, NULL, NULL, 120, 'active', 0, '', '{\"full_description\":\"These Makeup Remover Wipes quickly remove makeup, oil and impurities in one step. They are ideal for travel, the gym or late nights.\\n\\nTake a wipe and gently sweep over the face, eyes and lips until clean. Reseal the pack to keep the wipes fresh. Follow with cleanser if desired.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Makeup Remover Wipes\"},{\"key\":\"Skin Type\",\"value\":\"All Skin Types\"},{\"key\":\"Key Benefit\",\"value\":\"Quick one-step cleansing\"},{\"key\":\"Pack Size\",\"value\":\"30 wipes\"},{\"key\":\"Application\",\"value\":\"Sweep over face\"},{\"key\":\"Portable\",\"value\":\"Yes\"}]}', 2, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(204, 1, 53, 'cleansing-balm-makeup-removal', 'Cleansing Balm', 'A cleansing balm that melts makeup and sunscreen.', 'This Cleansing Balm transforms from a solid balm into a silky oil that melts away makeup, sunscreen and impurities. It leaves skin clean without stripping.\n\nMassage a small amount onto dry skin, then add water to emulsify and rinse thoroughly. Follow with your usual cleanser if desired.', 'A cleansing balm that melts makeup and sunscreen.', 11500.00, NULL, NULL, 60, 'active', 1, '', '{\"full_description\":\"This Cleansing Balm transforms from a solid balm into a silky oil that melts away makeup, sunscreen and impurities. It leaves skin clean without stripping.\\n\\nMassage a small amount onto dry skin, then add water to emulsify and rinse thoroughly. Follow with your usual cleanser if desired.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Cleansing Balm\"},{\"key\":\"Skin Type\",\"value\":\"All Skin Types\"},{\"key\":\"Key Benefit\",\"value\":\"Melts makeup and sunscreen\"},{\"key\":\"Weight\",\"value\":\"100g\"},{\"key\":\"Application\",\"value\":\"Massage on dry skin, rinse\"},{\"key\":\"Texture\",\"value\":\"Solid-to-oil balm\"}]}', 3, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(205, 1, 53, 'cleansing-oil-makeup-removal', 'Cleansing Oil', 'A cleansing oil for a thorough first cleanse.', 'This Cleansing Oil is a silky first-cleanse that lifts away makeup, sunscreen and sebum while keeping skin soft and comfortable. It rinses clean without residue.\n\nMassage onto dry skin, add water to emulsify, then rinse thoroughly. Follow with a gentle cleanser for a double cleanse.', 'A cleansing oil for a thorough first cleanse.', 10500.00, NULL, NULL, 65, 'active', 0, '', '{\"full_description\":\"This Cleansing Oil is a silky first-cleanse that lifts away makeup, sunscreen and sebum while keeping skin soft and comfortable. It rinses clean without residue.\\n\\nMassage onto dry skin, add water to emulsify, then rinse thoroughly. Follow with a gentle cleanser for a double cleanse.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Cleansing Oil\"},{\"key\":\"Skin Type\",\"value\":\"All Skin Types\"},{\"key\":\"Key Benefit\",\"value\":\"Thorough first cleanse\"},{\"key\":\"Volume\",\"value\":\"200ml\"},{\"key\":\"Application\",\"value\":\"Massage, emulsify, rinse\"},{\"key\":\"Rinses Clean\",\"value\":\"Yes\"}]}', 4, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(206, 1, 53, 'waterproof-makeup-remover', 'Waterproof Makeup Remover', 'A waterproof makeup remover for stubborn makeup.', 'This Waterproof Makeup Remover is formulated to dissolve long-wear and waterproof makeup, including mascara and eyeliner, without harsh rubbing.\n\nShake well, saturate a cotton pad, and press gently over the area for a few seconds before wiping. Rinse or follow with a cleanser.', 'A waterproof makeup remover for stubborn makeup.', 8500.00, NULL, NULL, 70, 'active', 0, '', '{\"full_description\":\"This Waterproof Makeup Remover is formulated to dissolve long-wear and waterproof makeup, including mascara and eyeliner, without harsh rubbing.\\n\\nShake well, saturate a cotton pad, and press gently over the area for a few seconds before wiping. Rinse or follow with a cleanser.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Makeup Remover\"},{\"key\":\"Skin Type\",\"value\":\"All Skin Types\"},{\"key\":\"Key Benefit\",\"value\":\"Dissolves waterproof makeup\"},{\"key\":\"Volume\",\"value\":\"150ml\"},{\"key\":\"Application\",\"value\":\"Shake, apply, wipe\"},{\"key\":\"Ophthalmologist-Tested\",\"value\":\"Yes\"}]}', 5, '2026-10-11 02:40:09', '2026-10-11 02:40:09'),
(207, 1, 53, 'reusable-makeup-remover-pads', 'Reusable Makeup Remover Pads', 'Reusable pads that remove makeup with just water.', 'These Reusable Makeup Remover Pads gently remove makeup, sunscreen and grime with just water. They are a soft, eco-friendly alternative to disposable cotton pads.\n\nWet the pad with warm water, wipe gently over the face and eyes, then rinse and machine-wash after use. Reuse for up to 1,000 washes.', 'Reusable pads that remove makeup with just water.', 6500.00, NULL, NULL, 100, 'active', 1, '', '{\"full_description\":\"These Reusable Makeup Remover Pads gently remove makeup, sunscreen and grime with just water. They are a soft, eco-friendly alternative to disposable cotton pads.\\n\\nWet the pad with warm water, wipe gently over the face and eyes, then rinse and machine-wash after use. Reuse for up to 1,000 washes.\",\"specifications\":[{\"key\":\"Product Type\",\"value\":\"Reusable Pads\"},{\"key\":\"Material\",\"value\":\"Soft microfibre\"},{\"key\":\"Pack Size\",\"value\":\"5 pads\"},{\"key\":\"Use\",\"value\":\"Water only\"},{\"key\":\"Care\",\"value\":\"Machine washable\"},{\"key\":\"Reusable\",\"value\":\"Up to 1,000 washes\"}]}', 6, '2026-10-11 02:40:09', '2026-10-11 02:40:09');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `storage_key` varchar(500) DEFAULT NULL,
  `alt_text` varchar(190) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_url`, `storage_key`, `alt_text`, `sort_order`, `created_at`) VALUES
(1, 4, 'products/c8614047173febd90eb8c39e6e5e0495.png', 'products/c8614047173febd90eb8c39e6e5e0495.png', 'Oud Royale Eau de', 1, '2026-10-09 20:51:03'),
(3, 4, 'products/8e0c6f64c156ff297f3875353a76b22a.jpg', 'products/8e0c6f64c156ff297f3875353a76b22a.jpg', 'Oud Royale Eau de', 2, '2026-10-09 20:51:03');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` int(10) UNSIGNED NOT NULL,
  `merchant_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(120) NOT NULL,
  `name` varchar(160) NOT NULL,
  `currency` varchar(8) NOT NULL DEFAULT 'Ôéª',
  `logo_url` varchar(500) DEFAULT NULL,
  `favicon_url` varchar(500) DEFAULT NULL,
  `theme_json` longtext DEFAULT NULL,
  `settings_json` longtext DEFAULT NULL,
  `status` enum('active','paused','deleted') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `merchant_id`, `slug`, `name`, `currency`, `logo_url`, `favicon_url`, `theme_json`, `settings_json`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'maison-ibra', 'MAISON IBRA', '₦', './assets/images/logo.png', './assets/images/icon-512x512.png', NULL, '{\"announce\": \"Complimentary delivery on orders above ₦150,000\", \"delivery\": {\"free_threshold\": 150000}}', 'active', '2026-10-09 12:17:23', '2026-10-09 12:18:30');

-- --------------------------------------------------------

--
-- Table structure for table `store_domains`
--

CREATE TABLE `store_domains` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `domain` varchar(190) NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `status` enum('pending','active','disabled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `store_domains`
--

INSERT INTO `store_domains` (`id`, `store_id`, `domain`, `is_primary`, `verified_at`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'localhost', 1, '2026-10-09 13:17:23', 'active', '2026-10-09 12:17:23', '2026-10-11 02:15:47'),
(2, 1, '127.0.0.1', 0, '2026-10-09 13:17:23', 'active', '2026-10-09 12:17:23', '2026-10-09 12:17:23'),
(3, 1, 'maison-ibra.local', 0, '2026-10-09 13:17:23', 'active', '2026-10-09 12:17:23', '2026-10-09 12:17:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `store_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `name` varchar(160) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('owner','manager','staff') NOT NULL DEFAULT 'owner',
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `store_id`, `email`, `name`, `password_hash`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin@maisonibra.local', 'MAISON IBRA Admin', '$2y$10$GDyHcWMT8KL0fl5Zxg7GkOet0lNezEPNadQ1OMcOc/VsEeJZOKZwW', 'owner', 'active', '2026-10-09 12:17:23', '2026-10-09 14:42:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_carts_token` (`cart_token`),
  ADD KEY `idx_carts_store` (`store_id`),
  ADD KEY `fk_carts_customer` (`customer_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cart_items_cart_product` (`cart_id`,`product_id`),
  ADD KEY `fk_cart_items_product` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_categories_store_slug` (`store_id`,`slug`),
  ADD KEY `idx_categories_parent` (`parent_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_customers_store_email` (`store_id`,`email`);

--
-- Indexes for table `merchants`
--
ALTER TABLE `merchants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_orders_store_number` (`store_id`,`order_number`),
  ADD KEY `idx_orders_store_created` (`store_id`,`created_at`),
  ADD KEY `fk_orders_customer` (`customer_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_items_order` (`order_id`),
  ADD KEY `fk_order_items_product` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_products_store_slug` (`store_id`,`slug`),
  ADD KEY `idx_products_store_status` (`store_id`,`status`),
  ADD KEY `idx_products_category` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_images_product` (`product_id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `fk_stores_merchant` (`merchant_id`);

--
-- Indexes for table `store_domains`
--
ALTER TABLE `store_domains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domain` (`domain`),
  ADD KEY `idx_domains_store` (`store_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_store_email` (`store_id`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `merchants`
--
ALTER TABLE `merchants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `store_domains`
--
ALTER TABLE `store_domains`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `fk_carts_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `fk_carts_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_cart_items_cart` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `fk_categories_parent` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_categories_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `fk_customers_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `fk_orders_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_products_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `fk_product_images_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stores`
--
ALTER TABLE `stores`
  ADD CONSTRAINT `fk_stores_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants` (`id`);

--
-- Constraints for table `store_domains`
--
ALTER TABLE `store_domains`
  ADD CONSTRAINT `fk_domains_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
