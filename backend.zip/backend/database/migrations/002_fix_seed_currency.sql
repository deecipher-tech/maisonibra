USE `e-commerce`;

UPDATE stores
SET currency = CONVERT(0xE282A6 USING utf8mb4),
    settings_json = JSON_SET(
      COALESCE(NULLIF(settings_json, ''), '{}'),
      '$.announce',
      CONCAT('Complimentary delivery on orders above ', CONVERT(0xE282A6 USING utf8mb4), '150,000')
    )
WHERE id = 1;
