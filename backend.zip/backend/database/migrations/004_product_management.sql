USE `e-commerce`;

ALTER TABLE products
  ADD COLUMN IF NOT EXISTS short_description TEXT NULL AFTER name,
  ADD COLUMN IF NOT EXISTS full_description MEDIUMTEXT NULL AFTER short_description,
  MODIFY status ENUM('draft','active','out_of_stock','archived') NOT NULL DEFAULT 'draft',
  MODIFY image_url VARCHAR(500) NOT NULL DEFAULT '';

UPDATE products
SET short_description = COALESCE(short_description, description),
    full_description = COALESCE(full_description, description),
    image_url = COALESCE(image_url, '')
WHERE short_description IS NULL OR full_description IS NULL OR image_url IS NULL;

ALTER TABLE product_images
  ADD COLUMN IF NOT EXISTS storage_key VARCHAR(500) NULL AFTER image_url;
