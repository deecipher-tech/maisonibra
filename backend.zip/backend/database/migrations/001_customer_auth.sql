USE `e-commerce`;

ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) NOT NULL AFTER phone,
  ADD COLUMN IF NOT EXISTS status ENUM('active','disabled') NOT NULL DEFAULT 'active' AFTER password_hash;
