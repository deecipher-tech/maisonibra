USE `e-commerce`;

UPDATE users
SET password_hash = '$2y$10$TI7I0iViW1uZHX1U6VYiqu9ijBV8069vNppnYDr3pKbq9huVqaPFy'
WHERE store_id = 1 AND email = 'admin@maisonibra.local';
